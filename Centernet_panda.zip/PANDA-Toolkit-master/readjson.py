"""
  The prog run centernet inference on given image_dir and output coco_formated.json.

  with independent preprocesssing
"""



import json

with open('../output_train/ctdet_hourglass_fbox.json' , 'r') as reader:
    jf = json.loads(reader.read())
    jf['type'] = 'instances'
#print(type(jf))
with open('./ctdet_hourglass_fbox.json' , 'w') as reader:
    json_str = json.dumps(jf)
    reader.write(json_str)
#for e in jf:
    #print(e)

with open('./transfered.json' , 'r') as reader:
    jf = json.loads(reader.read())
#print(type(jf))
for e in jf:
    print(e)
#print(jf['id'])

