# --------------------------------------------------------
# Compute metrics for detectors using ground-truth data
# Written by Wang Xueyang (wangxuey19@mails.tsinghua.edu.cn), Version 20200321
# Based on pycocotools (https://github.com/cocodataset/cocoapi/)
# --------------------------------------------------------

import numpy as np
import argparse

from pycocotools.coco import COCO
from pycocotools.cocoeval import COCOeval
import json
import os

def parse_args():
    """Defines and parses command-line arguments."""
    parser = argparse.ArgumentParser(description="""
Compute metrics for detectors using ground-truth data.

Files
-----
All result files have to comply with the COCO format described in
http://cocodataset.org/#format-results
Structure
---------

Layout for ground truth data
    <GT_ROOT>/anno.json'

Layout for test data
    <TEST_ROOT>/results.json
""", formatter_class=argparse.RawTextHelpFormatter)

    #parser.add_argument('--personfile', type=str, help='File path to person annotation json file')
    #parser.add_argument('--vehiclefile', type=str, help='File path to vehicle annotation json file')
    parser.add_argument('--model', type=str, help='model', default='')
    parser.add_argument('--box', type=str, help='box to evaluate', default='fbox')
    parser.add_argument('--result', type=str, help='File path to result json file.', default='result')
    parser.add_argument('--transfered', type=str, help='Directory containing transfered gt files', default='transfered.json')
    parser.add_argument('--annType', type=str, help='annotation type', default='bbox')
    parser.add_argument('--maxDets', type=list, help='[10, 100, 500] M = 3 thresholds on max detections per image',
                        default=[10, 100, 500])
    parser.add_argument('--areaRng', type=list, help='[...] A = 4 object area ranges for evaluation',
                        default=[0, 200, 400, 1e5])
    return parser.parse_args()


def main():
    args = parse_args()

    # transfer ground truth to COCO format
    #generate_coco_anno(args.personfile, args.vehiclefile, args.transfered)
    modelname = args.model
    boxname = args.box
    if boxname == 'fbox':
        transfer_path = '..\\experiments\\gt_fbox'
        transfer_json = ['transfered_fbox_fold1.json', 'transfered_fbox_fold2.json', 'transfered_fbox_fold3.json',
                              'transfered_fbox_fold4.json', 'transfered_fbox_fold5.json']
    elif boxname == 'vbox':
        transfer_path = '..\\experiments\\gt_vbox'
        transfer_json = ['transfered_vbox_fold1.json', 'transfered_vbox_fold2.json', 'transfered_vbox_fold3.json',
                              'transfered_vbox_fold4.json', 'transfered_vbox_fold5.json']
    elif boxname == 'hbox':
        transfer_path = '..\\experiments\\gt_hbox'
        transfer_json = ['transfered_hbox_fold1.json', 'transfered_hbox_fold2.json', 'transfered_hbox_fold3.json',
                              'transfered_hbox_fold4.json', 'transfered_hbox_fold5.json']
    else:
        print('you need to decide the boxname')

    result_path = os.path.join('..\\experiments\\', modelname)
    result_json = ['detres_nms_fold1.json', 'detres_nms_fold2.json', 'detres_nms_fold3.json', 'detres_nms_fold4.json',
                'detres_nms_fold5.json']


    AP_avg, AP_05_avg, AP_075_avg, AR_10_avg, AR_100_avg, AR_500_avg = 0,0,0,0,0,0
    AP_small_avg, AP_medium_avg, AP_large_avg = 0,0,0
    AR_small_avg, AR_medium_avg, AR_large_avg = 0, 0, 0
    for trans_jsonfile, res_jsonfile in zip(transfer_json, result_json):
        # initialize COCO ground truth api
        cocoGt = COCO(os.path.join(transfer_path, trans_jsonfile))

        # initialize COCO detections api

        cocoDt = cocoGt.loadRes(os.path.join(result_path, res_jsonfile))
        #print(cocoDt)
        imgIds = sorted(cocoGt.getImgIds())
        # random.shuffle(imgIds)

        cocoEval = COCOeval(cocoGt, cocoDt, args.annType)
        cocoEval.params.imgIds = imgIds
        cocoEval.params.maxDets = args.maxDets
        thres0, thres1, thres2, thres3 = args.areaRng
        cocoEval.params.areaRng = [[thres0 ** 2, thres3 ** 2],
                                   [thres0 ** 2, thres1 ** 2],
                                   [thres1 ** 2, thres2 ** 2],
                                   [thres2 ** 2, thres3 ** 2]]

        cocoEval.evaluate()
        cocoEval.accumulate()
        summarize(cocoEval)

        '''we use AP, AP_{IOU = 0.50}, AP_{IOU = 0.75}, AR_{max = 10}, AR_{max = 100}, AR_{max = 500} to evaluate'''
        AP, AP_05, AP_075, AP_small, AP_medium, AP_large, AR_10, AR_100, AR_500, AR_small, AR_medium, AR_large = cocoEval.stats
        print(AP, AP_05, AP_075, AR_10, AR_100, AR_500)
        AP_avg+=AP
        AP_05_avg+=AP_05
        AP_075_avg+=AP_075
        AR_10_avg+=AR_10
        AR_100_avg+=AR_100
        AR_500_avg+=AR_500
        AP_small_avg+=AP_small
        AP_medium_avg+=AP_medium
        AP_large_avg+=AP_large
        AR_small_avg += AR_small
        AR_medium_avg += AR_medium
        AR_large_avg += AR_large
    print('--------------------------------------------------------------------------------------------------------')
    print(modelname)
    print('Average')
    print('AP_0.5-0.75')
    print(str(AP_avg / len(transfer_json)), str(AP_05_avg / len(transfer_json)), str(AP_075_avg / len(transfer_json)))
    print('AR_10-500')
    print(str(AR_10_avg / len(transfer_json)), str(AR_100_avg / len(transfer_json)), str(AR_500_avg / len(transfer_json)))
    print('AP_small-large')
    print(str(AP_small_avg/len(transfer_json)), str(AP_medium_avg/len(transfer_json)), str(AP_large_avg/len(transfer_json)))
    print('AR_small-large')
    print(str(AR_small_avg / len(transfer_json)), str(AR_medium_avg / len(transfer_json)), str(AR_large_avg / len(transfer_json)))
    f = open(os.path.join(result_path, 'record.txt'), 'w')
    f.writelines('AP_0.5-0.75')
    f.writelines('\n')
    f.writelines([str(AP_avg / len(transfer_json)), str(AP_05_avg / len(transfer_json)), str(AP_075_avg / len(transfer_json))])
    f.writelines('\n')
    f.writelines('AR_10-500')
    f.writelines('\n')
    f.writelines([str(AR_10_avg / len(transfer_json)), str(AR_100_avg / len(transfer_json)), str(AR_500_avg / len(transfer_json))])
    f.writelines('\n')
    f.writelines('AP_small-large')
    f.writelines('\n')
    f.writelines([str(AP_small_avg/len(transfer_json)), str(AP_medium_avg/len(transfer_json)), str(AP_large_avg/len(transfer_json))])
    f.writelines('\n')
    f.writelines('AR_small-large')
    f.writelines('\n')
    f.writelines([str(AR_small_avg / len(transfer_json)), str(AR_medium_avg / len(transfer_json)), str(AR_large_avg / len(transfer_json))])
def summarize(self):
    '''
    Compute and display summary metrics for evaluation results.
    Note this functin can *only* be applied on the default parameter setting
    '''
    def _summarize(ap=1, iouThr=None, areaRng='all', maxDets=100):
        p = self.params
        iStr = ' {:<18} {} @[ IoU={:<9} | area={:>6s} | maxDets={:>3d} ] = {:0.3f}'
        titleStr = 'Average Precision' if ap == 1 else 'Average Recall'
        typeStr = '(AP)' if ap==1 else '(AR)'
        iouStr = '{:0.2f}:{:0.2f}'.format(p.iouThrs[0], p.iouThrs[-1]) \
            if iouThr is None else '{:0.2f}'.format(iouThr)

        aind = [i for i, aRng in enumerate(p.areaRngLbl) if aRng == areaRng]
        mind = [i for i, mDet in enumerate(p.maxDets) if mDet == maxDets]
        if ap == 1:
            # dimension of precision: [TxRxKxAxM]
            s = self.eval['precision']
            # IoU
            if iouThr is not None:
                t = np.where(iouThr == p.iouThrs)[0]
                s = s[t]
            s = s[:,:,:,aind,mind]
        else:
            # dimension of recall: [TxKxAxM]
            s = self.eval['recall']
            if iouThr is not None:
                t = np.where(iouThr == p.iouThrs)[0]
                s = s[t]
            s = s[:,:,aind,mind]
        if len(s[s>-1])==0:
            mean_s = -1
        else:
            mean_s = np.mean(s[s>-1])
        print(iStr.format(titleStr, typeStr, iouStr, areaRng, maxDets, mean_s))
        return mean_s
    def _summarizeDets():
        stats = np.zeros((12,))
        stats[0] = _summarize(1, maxDets=self.params.maxDets[2])
        stats[1] = _summarize(1, iouThr=.5, maxDets=self.params.maxDets[2])
        stats[2] = _summarize(1, iouThr=.75, maxDets=self.params.maxDets[2])
        stats[3] = _summarize(1, areaRng='small', maxDets=self.params.maxDets[2])
        stats[4] = _summarize(1, areaRng='medium', maxDets=self.params.maxDets[2])
        stats[5] = _summarize(1, areaRng='large', maxDets=self.params.maxDets[2])
        stats[6] = _summarize(0, maxDets=self.params.maxDets[0])
        stats[7] = _summarize(0, maxDets=self.params.maxDets[1])
        stats[8] = _summarize(0, maxDets=self.params.maxDets[2])
        stats[9] = _summarize(0, areaRng='small', maxDets=self.params.maxDets[2])
        stats[10] = _summarize(0, areaRng='medium', maxDets=self.params.maxDets[2])
        stats[11] = _summarize(0, areaRng='large', maxDets=self.params.maxDets[2])
        return stats
    if not self.eval:
        raise Exception('Please run accumulate() first')
    iouType = self.params.iouType
    if iouType == 'bbox':
        summarize = _summarizeDets
    self.stats = summarize()


if __name__ == '__main__':
    main()
