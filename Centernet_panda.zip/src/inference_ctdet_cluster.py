"""
  The prog run centernet inference on given image_dir and output coco_formated.json.

  with independent preprocesssing
"""
from __future__ import division
from __future__ import absolute_import
from __future__ import print_function

import _init_paths

import os
import cv2
import json

from os.path import join
from os.path import basename
from os.path import isfile

import time
from tqdm import tqdm

# pip install mmcv
import mmcv
import numpy as np

# pip install imagesize
import imagesize

#from datasets.dataset_factory import dataset_factory
from lib.detectors.detector_factory import detector_factory
from lib.opts import opts
from lib.external.nms import soft_nms
import json
input_information = {
    'mean': [0.408, 0.447, 0.470],
    'std': [0.289, 0.274, 0.278],
}

def _to_float(x):
    return float("{:.2f}".format(x))

def xywh2xyxy(_bbox):
    return [
        _bbox[0],
        _bbox[1],
        _bbox[2] + _bbox[0],
        _bbox[3] + _bbox[1],
    ]
def xywh2xyxy_ori(_bbox, x, y):
    return [
        _bbox[0]+x,
        _bbox[1]+y,
        _bbox[2] + _bbox[0] + x,
        _bbox[3] + _bbox[1] + y,
    ]
def xywh2xywh_ori(_bbox, x, y):
    return [
        _bbox[0]+x,
        _bbox[1]+y,
        _bbox[2] ,
        _bbox[3] ,
    ]
def xyxy_ori2xywh_ori(_bbox):
    return [
        _bbox[0],
        _bbox[1],
        _bbox[2] - _bbox[0],
        _bbox[3] - _bbox[1],
    ]
def convert_single_result(result, conf=0.0):
    _valid_ids = [3.]
    detections = []
    for cls_ind in result:
        category_id = _valid_ids[cls_ind - 1]
        for bbox in result[cls_ind]:
            score = bbox[4]

            if score < conf:
                continue

            bbox[2] -= bbox[0]
            bbox[3] -= bbox[1]
            bbox_out  = list(map(_to_float, bbox[0:4]))

            detection = {
                "category_id": int(category_id),
                "bbox": bbox_out,
                "score": float("{:.2f}".format(score))
            }
            # TODO: What?
            if len(bbox) > 5:
                extreme_points = list(map(_to_float, bbox[5:13]))
                detection["extreme_points"] = extreme_points
            detections.append(detection)
    return detections


def py_cpu_nms(dets, thresh):
    """Pure Python NMS baseline."""
    x1 = dets[:, 0]
    y1 = dets[:, 1]
    x2 = dets[:, 2]
    y2 = dets[:, 3]
    scores = dets[:, 4]  # bbox打分

    areas = (x2 - x1 + 1) * (y2 - y1 + 1)
    # 打分从大到小排列，取index
    order = scores.argsort()[::-1]
    # keep为最后保留的边框
    keep = []
    while order.size > 0:
        # order[0]是当前分数最大的窗口，肯定保留
        i = order[0]
        keep.append(i)
        # 计算窗口i与其他所有窗口的交叠部分的面积
        xx1 = np.maximum(x1[i], x1[order[1:]])
        yy1 = np.maximum(y1[i], y1[order[1:]])
        xx2 = np.minimum(x2[i], x2[order[1:]])
        yy2 = np.minimum(y2[i], y2[order[1:]])

        w = np.maximum(0.0, xx2 - xx1 + 1)
        h = np.maximum(0.0, yy2 - yy1 + 1)
        inter = w * h
        # 交/并得到iou值
        ovr = inter / (areas[i] + areas[order[1:]] - inter)
        # inds为所有与窗口i的iou值小于threshold值的窗口的index，其他窗口此次都被窗口i吸收
        inds = np.where(ovr <= thresh)[0]
        # order里面只保留与窗口i交叠面积小于threshold的那些窗口，由于ovr长度比order长度少1(不包含i)，所以inds+1对应到保留的窗口
        order = order[inds + 1]
    return keep
def py_cpu_nms_ext(dets, thresh):
    """Pure Python NMS baseline."""
    x1 = dets[:, 0]
    y1 = dets[:, 1]
    x2 = dets[:, 2]
    y2 = dets[:, 3]
    scores = dets[:, 4]  # bbox打分

    areas = (x2 - x1 + 1) * (y2 - y1 + 1)
    # 打分从大到小排列，取index
    order = scores.argsort()[::-1]
    # keep为最后保留的边框
    keep = []
    while order.size > 0:
        # order[0]是当前分数最大的窗口，肯定保留
        i = order[0]
        keep.append(i)
        # 计算窗口i与其他所有窗口的交叠部分的面积
        xx1 = np.maximum(x1[i], x1[order[1:]])
        yy1 = np.maximum(y1[i], y1[order[1:]])
        xx2 = np.minimum(x2[i], x2[order[1:]])
        yy2 = np.minimum(y2[i], y2[order[1:]])

        w = np.maximum(0.0, xx2 - xx1 + 1)
        h = np.maximum(0.0, yy2 - yy1 + 1)
        inter = w * h
        # 交/并得到iou值
        ovr = inter / (areas[i])
        over_ratio  = inter / ( areas[order[1:]])
        #over_ratio = 1-over_ratio
        # inds为所有与窗口i的iou值小于threshold值的窗口的index，其他窗口此次都被窗口i吸收
        inds = np.where(over_ratio < thresh)[0]
        # order里面只保留与窗口i交叠面积小于threshold的那些窗口，由于ovr长度比order长度少1(不包含i)，所以inds+1对应到保留的窗口
        order = order[inds + 1]
    return keep
def imshow_det_bboxes(img,
                      bboxes,
                      labels,
                      class_names=None,
                      score_thr=0,
                      bbox_color='green',
                      text_color='green',
                      thickness=1,
                      font_scale=0.5,
                      show=True,
                      win_name='',
                      wait_time=0,
                      out_file=None):
    """Draw bboxes and class labels (with scores) on an image.
    Args:
        img (str or ndarray): The image to be displayed.
        bboxes (ndarray): Bounding boxes (with scores), shaped (n, 4) or
            (n, 5).
        labels (ndarray): Labels of bboxes.
        class_names (list[str]): Names of each classes.
        score_thr (float): Minimum score of bboxes to be shown.
        bbox_color (str or tuple or :obj:`Color`): Color of bbox lines.
        text_color (str or tuple or :obj:`Color`): Color of texts.
        thickness (int): Thickness of lines.
        font_scale (float): Font scales of texts.
        show (bool): Whether to show the image.
        win_name (str): The window name.
        wait_time (int): Value of waitKey param.
        out_file (str or None): The filename to write the image.
    """
    assert bboxes.ndim == 2
    assert labels.ndim == 1
    assert bboxes.shape[0] == labels.shape[0]
    assert bboxes.shape[1] == 4 or bboxes.shape[1] == 5
    #img = cv2.imread(img)

    if score_thr > 0:
        assert bboxes.shape[1] == 5
        scores = bboxes[:, -1]
        inds = scores > score_thr
        bboxes = bboxes[inds, :]
        labels = labels[inds]

    bbox_color = (0, 255, 0)
    text_color = (0, 255, 0)

    for bbox, label in zip(bboxes, labels):
        bbox_int = bbox.astype(np.int32)
        left_top = (bbox_int[0], bbox_int[1])
        right_bottom = (bbox_int[2], bbox_int[3])
        cv2.rectangle(
            img, left_top, right_bottom, bbox_color, thickness=thickness)
        label_text = class_names[
            label] if class_names is not None else f'cls {label}'
        if len(bbox) > 4:
            label_text += f'|{bbox[-1]:.02f}'
        cv2.putText(img, label_text, (bbox_int[0], bbox_int[1] - 2),
                    cv2.FONT_HERSHEY_COMPLEX, font_scale, text_color, thickness=5)

    if out_file is not None:
        cv2.imwrite(out_file, img)
def main(args):
    for index in range(2, 6):
        args.load_model=args.load_model.split('/model_last')[0][:-1] + str(index) + '/model_last.pth'
        args.cropboxlist_dir=args.cropboxlist_dir.split('/')[0]+'/'+args.cropboxlist_dir.split('/')[-1].split('.')[0][:-1] + str(index) + '.json'
        args.output_dir=args.output_dir.split('/')[0][:-1] + str(index)
        print(args.load_model)
        print(args.cropboxlist_dir)
        print(args.output_dir)
        if args.image_dir is None:
            raise ValueError('No input!')
        seqs = os.listdir(args.image_dir)
        seqs = sorted(seqs)

            # input preprocessing configs
        args.mean = input_information['mean']
        args.std = input_information['std']
        args.input_w = args.image_size
        args.input_h = args.image_size
        args.reg_offset = not args.not_reg_offset

        print('confidence threshold: {}'.format(args.confidence))

        Detector = detector_factory[args.task]
        detector = Detector(args)

        inference_time = 0.0

        json_dict = {
            'images': [],
            'annotations': [],
            'categories': [
                {
                'supercategory': 'person',
                'id': 1,
                'name': 'person',
                }
            ],
        }
        json_dict={'annotations': []}
        image_id = 1
        bbox_id = 1
        ignore = 0
        category_id = 1
        with open(os.path.join(args.cropboxlist_dir), 'r') as reader:
            cropboxlist = json.loads(reader.read())

        #print(image_id)
        for _ in range(1):
            #print(seq)
            #image_dir = os.path.join(args.image_dir, seq)
            #cropboxlist_dir = os.path.join(args.cropboxlist_dir, seq)

            #image_filenames = [f for f in os.listdir(image_dir) if isfile(join(image_dir, f))]

            #image_filenames = sorted(image_filenames)
            if args.output_dir is not None and not os.path.exists(args.output_dir):
                os.makedirs(args.output_dir)

            for key in tqdm(cropboxlist.keys()):
                image_id = (int(key.split('/')[-1].split('_')[-2])-1)*30 +int(key.split('/')[-1].split('_')[-1][:-4])
                origin_image = None
                seq, img_file_name = key.split('/')
                output_dir = os.path.join(args.output_dir, seq)
                if not os.path.exists(output_dir):
                    os.makedirs(output_dir)
                image_dir = os.path.join(args.image_dir, seq)
                img_path = join(image_dir, img_file_name)
                image = cv2.imread(img_path)
                file_name = img_file_name[:-4]
                crop_boxes = cropboxlist[os.path.join(seq,img_file_name)]
                num=0
                total_bboxes =[]
                total_labels = []
                total_showbboxes = []
                total_showlabels = []
                for crop_box in crop_boxes:
                    loc = crop_box
                    #print(loc)
                    x0, y0, x1, y1 = int(loc[0]), int(loc[1]), int(loc[2]), int(loc[3])
                    #print([x0,])
                    crop_img = image[y0:y1, x0:x1]
                    start_time = time.time()
                    ret = detector.run(crop_img)
                    end_time = time.time()
                    inference_time += (end_time - start_time)
                    detections = convert_single_result(ret['results'])
                    for det in detections:
                        score = det['score']
                        if score < args.confidence:
                            continue
                        total_bboxes.append(
                            np.asarray([xywh2xyxy_ori(det['bbox'], x0, y0) + [det['score']]]))
                        total_labels.append(np.asarray([det['category_id']]))

                    if not args.no_image:
                        origin_image = cv2.imread(img_path)
                        origin_image = crop_img.copy()
                        output_img_dir = os.path.join(output_dir, file_name)
                        if not os.path.exists(output_img_dir):
                            os.makedirs(output_img_dir)
                        dst_img_path = os.path.join(output_img_dir, str(num)+'.jpg')
                        #print(dst_img_path)
                        # formatting
                        bboxes = np.asarray([xywh2xyxy(det['bbox']) + [det['score']] for det in detections])
                        labels = np.asarray([det['category_id'] for det in detections])
                        keep_id = py_cpu_nms(bboxes, 0.5)
                        bboxes = bboxes[keep_id]
                        labels = labels[keep_id]
                        total_showbboxes.append(np.asarray([xywh2xyxy_ori(det['bbox'], x0, y0) + [det['score']] for det in detections]))
                        total_showlabels.append(np.asarray([det['category_id'] for det in detections]))

                        imshow_det_bboxes(
                            origin_image,
                            bboxes,
                            labels,
                            class_names=['f'] * len(labels),
                            score_thr=args.confidence,
                            thickness=10,
                            font_scale=3,
                            show=False,
                            out_file=dst_img_path)

                    num+=1
                dst_img_path = os.path.join(output_dir, basename(img_path))
                total_bboxes = np.concatenate([_m.astype(np.float32) for _m in total_bboxes], 0)
                total_labels = np.concatenate([_m for _m in total_labels], 0)
                keep_id = soft_nms(total_bboxes, Nt=0.5, method=2)
                total_bboxes = total_bboxes[keep_id]
                total_labels = total_labels[keep_id]
                if args.nms_ext:
                    keep_id = py_cpu_nms_ext(total_bboxes, 0.9)
                    total_bboxes = total_bboxes[keep_id]
                    total_labels = total_labels[keep_id]
                total_showbboxes = total_bboxes
                total_showlabels = total_labels

                temp_bboxes = []
                for e in total_bboxes:
                    temp_bboxes.append(np.asarray([xyxy_ori2xywh_ori(e[:-1]) + [e[-1]]]))
                total_bboxes = np.concatenate([_m.astype(np.float32) for _m in temp_bboxes], 0)
                img_width, img_height = imagesize.get(img_path)
                image_info = {
                    'file_name': img_file_name,
                    'height': img_height,
                    'width': img_width,
                    'id': image_id,
                }

                #json_dict['images'].append(image_info)

                for bboxes, labels in zip(total_bboxes, total_labels):
                    score = bboxes[4].item()
                    # if score < args.confidence:
                    #    continue
                    bbox = [bboxes[0].item(), bboxes[1].item(), bboxes[2].item(), bboxes[3].item()]
                    #category_id = labels.item()
                    category_id = int(3)
                    xmin, ymin, w, h = bbox
                    #w = (xmax-xmin+1)
                    #h = (ymax-ymin+1)
                    annotation = {
                        'area': w * h,
                        'iscrowd': ignore,
                        'image_id': image_id,
                        'bbox': bbox,
                        'category_id': int(args.category_id),
                        'id': bbox_id,
                        'ignore': ignore,
                        'score': score,
                        'segmentation': [],
                    }
                    if score>args.confidence:
                        json_dict['annotations'].append(annotation)
                    #    json_dict.append(annotation)
                    bbox_id += 1
                image_id += 1
                if not args.no_image:
                    image = cv2.imread(img_path)
                    #total_showbboxes = np.concatenate([_m.astype(np.float32) for _m in total_showbboxes], 0)
                    #total_showlabels = np.concatenate([_m for _m in total_showlabels], 0)
                    imshow_det_bboxes(
                        image,
                        total_showbboxes,
                        total_showlabels,
                        class_names=['f'] * len(total_labels),
                        score_thr=args.confidence,
                        thickness=12,
                        font_scale=6,
                        show=False,
                        out_file=dst_img_path)
            if not args.no_image:
                break
            # add to json_out
        if args.no_image:
            prediction_output_path = os.path.join(args.output_dir, os.path.basename(args.load_model)).rstrip('.pth') + '.json'
            with open(prediction_output_path, 'w') as json_fp:
                json_str = json.dumps(json_dict)
                json_fp.write(json_str)
    #print('Average inference time: {} ms'.format(1000.0* (inference_time / len(image_filenames))))

if __name__ == '__main__':
    
    opt = opts()
    
    opt.parser.add_argument('-is', '--image_size', type=int, default=1024)
    opt.parser.add_argument('-nc', '--num_classes', type=int, default=1)
    opt.parser.add_argument('-catid', '--category_id', type=str, default=2, help='Output directory')
    # inference configs 
    opt.parser.add_argument('-id', '--image_dir', type=str, default=None, help='Input image directory')
    opt.parser.add_argument('-cbld', '--cropboxlist_dir', type=str, default=None, help='Croppedimage list directory')
    opt.parser.add_argument('-od', '--output_dir', type=str, default=None, help='Output directory')
    opt.parser.add_argument('-conf', '--confidence', type=float, default=0.4, help='')
    opt.parser.add_argument('--no-image', action='store_true', help='If set, the predicted images will not be saved.')
    opt.parser.add_argument('--nms_ext', action='store_true', help='If set, new nms strategy will be applied.')
    #opt.parser.add_argument('--load_model', type=str, default='', help='path')
    
    #opt.parser.add_argument('--gpus', default=0,
    #                         help='-1 for CPU, use comma for multiple gpus')
    args = opt.parse()

    # CTDET_HEAD
    args.heads = {'hm': 1, 'wh': 2, 'reg': 2}

    main(args)
