"""
  The prog run centernet inference on given image_dir and output coco_formated.json.

  with independent preprocesssing
"""



import json

with open('../transfered.json' , 'r') as reader:
    jf = json.loads(reader.read())

print(jf['images'])