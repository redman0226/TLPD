"""
  The prog run centernet inference on given image_dir and output coco_formated.json.

  with independent preprocesssing
"""


import os
import cv2
import json

from os.path import join
from os.path import basename
from os.path import isfile

import time
from tqdm import tqdm

import json



def _to_float(x):
    return float("{:.2f}".format(x))

def xywh2xyxy(_bbox):
    return [
        _bbox[0],
        _bbox[1],
        _bbox[2] + _bbox[0],
        _bbox[3] + _bbox[1],
    ]
def xywh2xyxy_ori(_bbox, x, y):
    return [
        _bbox[0]+x,
        _bbox[1]+y,
        _bbox[2] + _bbox[0] + x,
        _bbox[3] + _bbox[1] + y,
    ]
def xywh2xywh_ori(_bbox, x, y):
    return [
        _bbox[0]+x,
        _bbox[1]+y,
        _bbox[2] ,
        _bbox[3],
    ]
def convert_single_result(result, conf=0.0):
    _valid_ids = [1.]
    detections = []
    for cls_ind in result:
        category_id = _valid_ids[cls_ind - 1]
        for bbox in result[cls_ind]:
            score = bbox[4]

            if score < conf:
                continue

            bbox[2] -= bbox[0]
            bbox[3] -= bbox[1]
            bbox_out  = list(map(_to_float, bbox[0:4]))

            detection = {
                "category_id": int(category_id),
                "bbox": bbox_out,
                "score": float("{:.2f}".format(score))
            }
            # TODO: What?
            if len(bbox) > 5:
                extreme_points = list(map(_to_float, bbox[5:13]))
                detection["extreme_points"] = extreme_points
            detections.append(detection)
    return detections


def py_cpu_nms(dets, thresh):
    """Pure Python NMS baseline."""
    x1 = dets[:, 0]
    y1 = dets[:, 1]
    x2 = dets[:, 2]
    y2 = dets[:, 3]
    scores = dets[:, 4]  # bbox打分

    areas = (x2 - x1 + 1) * (y2 - y1 + 1)
    # 打分从大到小排列，取index
    order = scores.argsort()[::-1]
    # keep为最后保留的边框
    keep = []
    while order.size > 0:
        # order[0]是当前分数最大的窗口，肯定保留
        i = order[0]
        keep.append(i)
        # 计算窗口i与其他所有窗口的交叠部分的面积
        xx1 = np.maximum(x1[i], x1[order[1:]])
        yy1 = np.maximum(y1[i], y1[order[1:]])
        xx2 = np.minimum(x2[i], x2[order[1:]])
        yy2 = np.minimum(y2[i], y2[order[1:]])

        w = np.maximum(0.0, xx2 - xx1 + 1)
        h = np.maximum(0.0, yy2 - yy1 + 1)
        inter = w * h
        # 交/并得到iou值
        ovr = inter / (areas[i] + areas[order[1:]] - inter)
        # inds为所有与窗口i的iou值小于threshold值的窗口的index，其他窗口此次都被窗口i吸收
        inds = np.where(ovr <= thresh)[0]
        # order里面只保留与窗口i交叠面积小于threshold的那些窗口，由于ovr长度比order长度少1(不包含i)，所以inds+1对应到保留的窗口
        order = order[inds + 1]
    return keep

def py_cpu_nms_ext(dets, thresh):
    """Pure Python NMS baseline."""
    x1 = dets[:, 0]
    y1 = dets[:, 1]
    x2 = dets[:, 2]
    y2 = dets[:, 3]
    scores = dets[:, 4]  # bbox打分

    areas = (x2 - x1 + 1) * (y2 - y1 + 1)
    # 打分从大到小排列，取index
    order = scores.argsort()[::-1]
    # keep为最后保留的边框
    keep = []
    while order.size > 0:
        # order[0]是当前分数最大的窗口，肯定保留
        i = order[0]
        keep.append(i)
        # 计算窗口i与其他所有窗口的交叠部分的面积
        xx1 = np.maximum(x1[i], x1[order[1:]])
        yy1 = np.maximum(y1[i], y1[order[1:]])
        xx2 = np.minimum(x2[i], x2[order[1:]])
        yy2 = np.minimum(y2[i], y2[order[1:]])

        w = np.maximum(0.0, xx2 - xx1 + 1)
        h = np.maximum(0.0, yy2 - yy1 + 1)
        inter = w * h
        # 交/并得到iou值
        ovr = inter / (areas[i])
        over_ratio  = inter / ( areas[order[1:]])
        over_ratio = 1-over_ratio
        # inds为所有与窗口i的iou值小于threshold值的窗口的index，其他窗口此次都被窗口i吸收
        inds = np.where(over_ratio > thresh)[0]
        # order里面只保留与窗口i交叠面积小于threshold的那些窗口，由于ovr长度比order长度少1(不包含i)，所以inds+1对应到保留的窗口
        order = order[inds + 1]
    return keep

def main():
    total_bboxes = []
    with open('../vHg.json', 'r') as reader:
        jf = json.loads(reader.read())
        anno = jf['annotations']
        for info in anno:
            #print(info)
            #print(len(info))
            box = info['bbox']
            score = info['score']
            total_bboxes.append(np.asarray([box+score]))
'''
            
            total_bboxes = np.concatenate([_m.astype(np.float32) for _m in total_bboxes], 0)
            total_labels = np.concatenate([_m for _m in total_labels], 0)
            keep_id = soft_nms(total_bboxes, Nt=0.5, method=2)
            total_bboxes = total_bboxes[keep_id]
            total_labels = total_labels[keep_id]

            keep_id = soft_nms(total_bboxes, Nt=0.5, method=2)
            total_bboxes = total_bboxes[keep_id]
            total_labels = total_labels[keep_id]
            img_width, img_height = imagesize.get(img_path)
            image_info = {
                'file_name': img_file_name,
                'height': img_height,
                'width': img_width,
                'id': image_id,
            }

            json_dict['images'].append(image_info)

            for bboxes, labels in zip(total_bboxes, total_labels):
                score = bboxes[4].item()
                # if score < args.confidence:
                #    continue
                bbox = [bboxes[0].item(), bboxes[1].item(), bboxes[2].item(), bboxes[3].item()]
                category_id = labels.item()
                #print(type(category_id))
                xmin, ymin, w, h = bbox
                #w = (xmax-xmin+1)
                #h = (ymax-ymin+1)
                annotation = {
                    'area': w * h,
                    'iscrowd': ignore,
                    'image_id': image_id,
                    'bbox': bbox,
                    'category_id': category_id,
                    'id': bbox_id,
                    'ignore': ignore,
                    'score': score,
                    'segmentation': [],
                }

                json_dict['annotations'].append(annotation)
                bbox_id += 1
            image_id += 1
            if not args.no_image:
                image = cv2.imread(img_path)
                imshow_det_bboxes(
                    image,
                    total_bboxes,
                    total_labels,
                    class_names=['f'] * len(total_labels),
                    score_thr=args.confidence,
                    thickness=12,
                    font_scale=6,
                    show=False,
                    out_file=dst_img_path)

    with open(prediction_output_path, 'w') as json_fp:
        json_str = json.dumps(json_dict)
        json_fp.write(json_str)
    print('Average inference time: {} ms'.format(1000.0* (inference_time / len(image_filenames))))
'''
if __name__ == '__main__':


    main()
