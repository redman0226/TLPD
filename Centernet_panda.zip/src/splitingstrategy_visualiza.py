"""
  The prog run centernet inference on given image_dir and output coco_formated.json.

  with independent preprocesssing
"""
from shapely.geometry import Point
from shapely.geometry.polygon import Polygon


import _init_paths

import os
import cv2
import json

from os.path import join
from os.path import basename
from os.path import isfile

import time
from tqdm import tqdm

# pip install mmcv
import mmcv
import numpy as np

# pip install imagesize
import imagesize

import json
input_information = {
    'mean': [0.408, 0.447, 0.470],
    'std': [0.289, 0.274, 0.278],
}

def py_cpu_nms(dets, thresh):
    """Pure Python NMS baseline."""
    x1 = dets[:, 0]
    y1 = dets[:, 1]
    x2 = dets[:, 2]
    y2 = dets[:, 3]
    scores = dets[:, 4]  # bbox打分

    areas = (x2 - x1 + 1) * (y2 - y1 + 1)
    # 打分从大到小排列，取index
    order = scores.argsort()[::-1]
    # keep为最后保留的边框
    keep = []
    while order.size > 0:
        # order[0]是当前分数最大的窗口，肯定保留
        i = order[0]
        keep.append(i)
        # 计算窗口i与其他所有窗口的交叠部分的面积
        xx1 = np.maximum(x1[i], x1[order[1:]])
        yy1 = np.maximum(y1[i], y1[order[1:]])
        xx2 = np.minimum(x2[i], x2[order[1:]])
        yy2 = np.minimum(y2[i], y2[order[1:]])

        w = np.maximum(0.0, xx2 - xx1 + 1)
        h = np.maximum(0.0, yy2 - yy1 + 1)
        inter = w * h
        # 交/并得到iou值
        ovr = inter / (areas[i] + areas[order[1:]] - inter)
        # inds为所有与窗口i的iou值小于threshold值的窗口的index，其他窗口此次都被窗口i吸收
        inds = np.where(ovr <= thresh)[0]
        # order里面只保留与窗口i交叠面积小于threshold的那些窗口，由于ovr长度比order长度少1(不包含i)，所以inds+1对应到保留的窗口
        order = order[inds + 1]
    return keep
def py_cpu_nms_ext(dets, thresh):
    """Pure Python NMS baseline."""
    x1 = dets[:, 0]
    y1 = dets[:, 1]
    x2 = dets[:, 2]
    y2 = dets[:, 3]
    scores = dets[:, 4]  # bbox打分

    areas = (x2 - x1 + 1) * (y2 - y1 + 1)
    # 打分从大到小排列，取index
    order = scores.argsort()[::-1]
    # keep为最后保留的边框
    keep = []
    while order.size > 0:
        # order[0]是当前分数最大的窗口，肯定保留
        i = order[0]
        keep.append(i)
        # 计算窗口i与其他所有窗口的交叠部分的面积
        xx1 = np.maximum(x1[i], x1[order[1:]])
        yy1 = np.maximum(y1[i], y1[order[1:]])
        xx2 = np.minimum(x2[i], x2[order[1:]])
        yy2 = np.minimum(y2[i], y2[order[1:]])

        w = np.maximum(0.0, xx2 - xx1 + 1)
        h = np.maximum(0.0, yy2 - yy1 + 1)
        inter = w * h
        # 交/并得到iou值
        ovr = inter / (areas[i])
        over_ratio  = inter / ( areas[order[1:]])
        #over_ratio = 1-over_ratio
        # inds为所有与窗口i的iou值小于threshold值的窗口的index，其他窗口此次都被窗口i吸收
        inds = np.where(over_ratio < thresh)[0]
        # order里面只保留与窗口i交叠面积小于threshold的那些窗口，由于ovr长度比order长度少1(不包含i)，所以inds+1对应到保留的窗口
        order = order[inds + 1]
    return keep
def imshow_det_bboxes(img,
                      bboxes,
                      labels,
                      class_names=None,
                      score_thr=0,
                      bbox_color='green',
                      text_color='green',
                      thickness=1,
                      font_scale=0.5,
                      show=True,
                      win_name='',
                      wait_time=0,
                      out_file=None):
    """Draw bboxes and class labels (with scores) on an image.
    Args:
        img (str or ndarray): The image to be displayed.
        bboxes (ndarray): Bounding boxes (with scores), shaped (n, 4) or
            (n, 5).
        labels (ndarray): Labels of bboxes.
        class_names (list[str]): Names of each classes.
        score_thr (float): Minimum score of bboxes to be shown.
        bbox_color (str or tuple or :obj:`Color`): Color of bbox lines.
        text_color (str or tuple or :obj:`Color`): Color of texts.
        thickness (int): Thickness of lines.
        font_scale (float): Font scales of texts.
        show (bool): Whether to show the image.
        win_name (str): The window name.
        wait_time (int): Value of waitKey param.
        out_file (str or None): The filename to write the image.
    """
    assert bboxes.ndim == 2
    assert labels.ndim == 1
    assert bboxes.shape[0] == labels.shape[0]
    assert bboxes.shape[1] == 4 or bboxes.shape[1] == 5
    #img = cv2.imread(img)

    if score_thr > 0:
        assert bboxes.shape[1] == 5
        scores = bboxes[:, -1]
        inds = scores > score_thr
        bboxes = bboxes[inds, :]
        labels = labels[inds]

    bbox_color = (0, 255, 0)
    text_color = (0, 255, 0)

    for bbox, label in zip(bboxes, labels):
        bbox_int = bbox.astype(np.int32)
        left_top = (bbox_int[0], bbox_int[1])
        right_bottom = (bbox_int[2], bbox_int[3])
        cv2.rectangle(
            img, left_top, right_bottom, bbox_color, thickness=thickness)
        label_text = class_names[
            label] if class_names is not None else f'cls {label}'
        if len(bbox) > 4:
            label_text += f'|{bbox[-1]:.02f}'
        cv2.putText(img, label_text, (bbox_int[0], bbox_int[1] - 2),
                    cv2.FONT_HERSHEY_COMPLEX, font_scale, text_color, thickness=5)

    if out_file is not None:
        cv2.imwrite(out_file, img)
def drawline(img,pt1,pt2,color,thickness=1,style='dotted',gap=20):
    dist =((pt1[0]-pt2[0])**2+(pt1[1]-pt2[1])**2)**.5
    pts= []
    for i in  np.arange(0,dist,gap):
        r=i/dist
        x=int((pt1[0]*(1-r)+pt2[0]*r)+.5)
        y=int((pt1[1]*(1-r)+pt2[1]*r)+.5)
        p = (x,y)
        pts.append(p)

    if style=='dotted':
        for p in pts:
            cv2.circle(img,p,thickness,color,-1)
    else:
        s=pts[0]
        e=pts[0]
        i=0
        for p in pts:
            s=e
            e=p
            if i%2==1:
                cv2.line(img,s,e,color,thickness)
            i+=1

def drawpoly(img,pts,color,thickness=1,style='dotted',):
    s=pts[0]
    e=pts[0]
    pts.append(pts.pop(0))
    for p in pts:
        s=e
        e=p
        drawline(img,s,e,color,thickness,style)

def drawrect(img,pt1,pt2,color,thickness=1,style='dotted'):
    pts = [pt1,(pt2[0],pt1[1]),pt2,(pt1[0],pt2[1])]
    drawpoly(img,pts,color,thickness,style)
def main():
    image_path = 'E:\\CenterNet-master\\experiments'
    seqs = os.listdir('..\\images\\')
    seqs = sorted(seqs)
    out = 'split_out_averaged'
    for seq in seqs:
        if not os.path.exists(out):
            os.makedirs(out)
        output_dir = os.path.join(out, seq)
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)
        # input preprocessing configs
    inference_time = 0.0
    split_jsons = ['split_crowd_fold3.json']
    transfer_json = ['transfered_fbox_fold3.json']
    splits = ['average', 'boxbased']
    transfers = ['vbox','hbox' ]
    total_num_truncatedbox = 0
    total_num_images = 0
    avgboxesofimages=0
    avg_num_images =0
    num_whole_image = 0
    id_dict = {}
    for trans_jsonfile, split_json in zip(transfer_json, split_jsons):

        split_json = split_json.replace('crowd', splits[0])
        #trans_jsonfile = trans_jsonfile.replace('fbox', transfers[1])
        print(split_json)
        print(trans_jsonfile)
        jsonfile = os.path.join(image_path, 'split', split_json)
        gtboxesfile = os.path.join(image_path, 'gt_fbox', trans_jsonfile)
        with open(jsonfile, 'r') as reader:
            jf_split = json.loads(reader.read())
        with open(gtboxesfile, 'r') as reader:
            jf_boxes = json.loads(reader.read())
        num_whole_image+=len(jf_boxes['images'])
        for image_split in jf_split:
            if True:#if image_split == '13_University_Playground/IMG_13_27.jpg':
                print(image_split)
                cropimage_loc = jf_split[image_split]
                image_infos = jf_boxes['images']
                for info in image_infos:
                    if info['file_name'] == image_split:
                        #print(image_split)
                        id = info['id']
                        img = cv2.imread(os.path.join('..\\images\\', image_split))
                        img_clone = cv2.imread(os.path.join('..\\images\\', image_split))
                        y_len = img.shape[0]
                        x_len = img.shape[1]
                        break
                targetbox=[]
                for bboxes in jf_boxes['annotations']:
                    if bboxes['image_id'] == id:
                        bbox = bboxes['bbox']
                        b_x0, b_y0, b_x1, b_y1 = int(bbox[0]), int(bbox[1]), int(bbox[2] + bbox[0]), int(bbox[3] + bbox[1])
                        targetbox.append([b_x0, b_y0, b_x1, b_y1])
    #                print()
                numofsubimages = 0
                truncatedboxofsubimages = 0
                thickness=60
                color = (255,0,0)
                splitout = os.path.join(out, image_split[:-4])
                if not os.path.exists(splitout):
                    os.makedirs(splitout)
                num=1
                for loc in cropimage_loc:
                    numofsubimages+=1
                    total_num_images+=1
                    x0, y0, x1, y1 = int(loc[0]), int(loc[1]), int(loc[2]), int(loc[3])
                    #img_clone = img.copy()
                    crop_img = img_clone[y0:y1, x0:x1].copy()
                    cv2.imwrite(os.path.join(splitout, image_split.split('/')[-1][:-4] + '_' + str(num) + '.png'), crop_img)
                    #polygon = Polygon([(x0,y0), (x0, y1), (x1,y0), (x1,y1)])

                    if numofsubimages%15==0:
                        color = (255, 0, 0)
                        cv2.line(img, (x0, y0), (x1, y0), color, thickness)
                        cv2.line(img, (x0, y0), (x0, y1), color, thickness)
                        cv2.line(img, (x0, y1), (x1, y1), color, thickness)
                        cv2.line(img, (x1, y0), (x1, y1), color, thickness)
                    elif numofsubimages>150:
                        color = ( 255, 0, 0)
                        cv2.line(img, (x0, y0), (x1, y0), color, thickness)
                        cv2.line(img, (x0, y0), (x0, y1), color, thickness)
                        cv2.line(img, (x0, y1), (x1, y1), color, thickness)
                        cv2.line(img, (x1, y0), (x1, y1), color, thickness)
                    else:
                        color = (255, 0, 0)
                        cv2.line(img, (x0, y0), (x1, y0), color, thickness)
                        cv2.line(img, (x0, y0), (x0, y1), color, thickness)
                        cv2.line(img, (x0, y1), (x1, y1), color, thickness)
                        cv2.line(img, (x1, y0), (x1, y1), color, thickness)

                    color = (255, 0, 0)
                    #cv2.line(img, (x0, y0), (x1, y0), color, thickness)
                    #cv2.line(img, (x0, y0), (x0, y1), color, thickness)
                    #cv2.line(img, (x0, y1), (x1, y1), color, thickness)
                    #cv2.line(img, (x1, y0), (x1, y1), color, thickness)
                    num+=1
                    '''
                    if x0 not in x_dict and x0 != 0 and x0 != x_len:
                        x_dict.append(x0)
                        cv2.line(img, (x0, 0), (x0, y_len), color, thickness)
                    if x1 not in x_dict and x1 != 0 and x1 != x_len:
                        x_dict.append(x1)
                        cv2.line(img, (x1, 0), (x1, y_len), color, thickness)
                    if y0 not in y_dict and y0 != 0 and y0 != y_len:
                        y_dict.append(y0)
                        cv2.line(img, (0, y0), (x_len, y0), color, thickness)
                    if y1 not in y_dict and y1 != 0 and y1 != y_len:
                        y_dict.append(y1)
                        cv2.line(img, (0, y1), (x_len, y1), color, thickness)
                    '''


                    for tbox in targetbox:
                        b_x0, b_y0, b_x1, b_y1 = tbox[0], tbox[1], tbox[2], tbox[3]
                        points=[Point(b_x0, b_y0), Point(b_x0, b_y1), Point(b_x1, b_y0), Point(b_x1, b_y1)]
                        #num_p=0
                        #for point in points:
                        #    if polygon.contains(point):
                        #        num_p+=1
                        xx1 = np.maximum(x0, b_x0)
                        yy1 = np.maximum(y0, b_y0)
                        xx2 = np.minimum(x1, b_x1)
                        yy2 = np.minimum(y1, b_y1)

                        w = np.maximum(0.0, xx2 - xx1 + 1)
                        h = np.maximum(0.0, yy2 - yy1 + 1)
                        inter = w * h
                        # 交/并得到iou值
                        areas = (b_x1 - b_x0 + 1) * (b_y1 - b_y0 + 1)
                        ovr = inter / (areas)
                        if ovr>0.01 and ovr<0.99:
                            total_num_truncatedbox+=1
                            truncatedboxofsubimages+=1
                            left_top = (b_x0, b_y0)
                            right_bottom = (b_x1, b_y1)
                            cv2.rectangle(
                                img, left_top, right_bottom, (0,0,255), thickness=60)

                #print(os.path.join(out, image_split))
                print(numofsubimages)
                avgboxesofimages+=truncatedboxofsubimages/numofsubimages
                avg_num_images+=1
                cv2.imwrite(os.path.join(out, image_split), img)


    print('Number of truncated boxes: {} '.format(total_num_truncatedbox))
    print('AVG of truncated boxes of each whole image: {} '.format(total_num_truncatedbox/num_whole_image))
    print('AVG of truncated boxes: {} '.format(total_num_truncatedbox/total_num_images))
    print('AVG of truncated boxes of each image: {} '.format(avgboxesofimages / avg_num_images))
if __name__ == '__main__':

    main()
