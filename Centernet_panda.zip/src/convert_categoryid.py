import os
import json
transfer_json = ['transfered_hbox_fold1.json', 'transfered_hbox_fold2.json', 'transfered_hbox_fold3.json',
                     'transfered_hbox_fold4.json', 'transfered_hbox_fold5.json']
detres_json = ['detres_nms_fold1.json', 'detres_nms_fold2.json', 'detres_nms_fold3.json', 'detres_nms_fold4.json',
                'detres_nms_fold5.json']
jsons = detres_json

for jsonfile in jsons:
    id_dict = {}
    print(jsonfile)
    with open(os.path.join('../experiments/Centernet',jsonfile), 'r') as reader:
        jf_split = json.loads(reader.read())
        #data = jf_split['annotations']
        #########change category_id#######
        for d in jf_split['annotations']:
            d['category_id']= int(2.)
        #for d in jf_split:
        #    if d['image_id'] not in id_dict:
        #        id_dict[d['image_id']]=[]
        #    else:
        #        id_dict[d['image_id']].append(d)
    with open(jsonfile, 'w') as json_fp:
        json_str = json.dumps(jf_split)
        json_fp.write(json_str)
    '''
    finaljson = []
    for id in id_dict.keys():
        id_dict[id] = sorted(id_dict[id], key=lambda s: s['score'], reverse=True)
        finaljson.extend(id_dict[id])
    print(len(finaljson))
    with open(jsonfile, 'w') as json_fp:
        json_str = json.dumps(finaljson)
        json_fp.write(json_str)
    '''