# placement
src/inference_ctdet.py

# Package requirements
tqdm
mmcv
imagesize

# Paths to define
1. model_path
2. input_path
3. output_path

# Arugments
src/inference_ctdet.py ctdet --load_model <model_path>  -id <input_path> -od <output_path> -conf <confidence_threshold> --arch <model_arch>

ctdet : the defualt task for the inference
--load_model : the model file full path
-id,--image_dir : input_path
-od,--output_dir : output_path
-conf,--confidence: confidence_threshold
--arch : model architecture (hourglass, or default dla_34)
--cbld : input split file path
--nms_ext : utilize new nms strategy
--padding : you can set the ratio you want to pad the image with zeros.
--no-image : If set, the predicted images will not be saved.

# Examples

python src/inference_ctdet.py ctdet --load_model ./models/vHg.pth  -id ./image_train/ -cbld ./train_split_Cluster_Counting/ -od ./output/ -conf .05 --arch hourglass -is 1024 --nms_ext --padding 0 --no-image

python src/inference_ctdet.py ctdet --load_model ./models/hCD.pth  -id ./image_train/ -catid 3 -cbld ./train_split_Cluster_Counting/ -od ./output_headbox/ -conf .05 -is 800 --nms_ori --nms_ext --padding 0 --no-image